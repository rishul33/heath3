﻿<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
	<script type="text/javascript" src="//nexus.ensighten.com/mayo_clinic/clinicprod/Bootstrap.js"></script>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Web site unavailable</title>
	<style type="text/css">
		body {
			background: #F5F5F3;
			padding: 100px 0 0 0;
			font-family: Helvetica, Arial, sans-serif;
		}

		#MainContent {
			position: relative;
			width: 540px;
			padding: 30px;
			margin: auto;
			background: #ffffff url(/mymayo/img/logo.png) no-repeat left 30px;
		}

			#MainContent p {
				margin: 0 0 15px 100px;
				color: #444444;
				font-size: 12px;
			}

		a {
			color: #60A2B9;
		}

			a:hover {
				text-decoration: none;
			}

		h1 {
			margin: 0 0 15px 125px;
			color: #444444;
			font-size: 24px;
		}
	</style>
</head>
<body>
	<div id="MainContent">
		<h1>Page Not Found</h1>

		<p>For access to Patient Online Services, click: <a href="https://gpsnetx.mayoclinic.org/psi/content/staticpatient/showpage/patientonline">Patient Online Services</a></p>

		<p>For access to Professional Online Services click: <a href="https://medprof.mayoclinic.org/">Professional Online Services</a></p>

		<p>If you are trying to reach Mayo Clinic to schedule an appointment, please contact us at the numbers below:</p>

		<p><b>Arizona</b>: 800-446-2279 (toll-free)</p>

		<p><b>Florida</b>: 904-953-0853</p>

		<p><b>Minnesota</b>: 507-538-3270</p>

		<p><b>Mayo Clinic Children’s Center</b>: 855-MAYO-KID (855-629-6543, toll-free)</p>

		<p>You can also request an appointment via the Mayo Clinic app.</p>

		<p>Sincerely,</p>

		<p>The team at Mayo Clinic</p>
	</div>
</body>
</html>